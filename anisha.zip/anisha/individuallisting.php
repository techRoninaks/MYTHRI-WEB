<!DOCTYPE html>
<html><title>11.php</title>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
  background:white;
}
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 5px;
  height: 220px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.content {
max-width: 800px;
  height: 800px;
  margin: auto;
  background: white;
  padding: 10px;
}

a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}


.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #f1f1f1;
  color: black;
}

.round{
  border-squre: 50%;
}

div.absolute {
float: right;
  }

img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
button {
  background-color: lightgrey;
  border: none;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>

</head>
<body>

  <p>>HOME>EVENTS.A DAY FOR THE SPECIAL ONES</p>
  <hr>
  <div class="content">
 <div class="row">
   <div class="column" style="background-color:white;">
     <h3><strong>BOYS HOME</strong></h3>
     <h4 style="color:#787878">GURUVAYOUR</h4>
     <h4 style="color:#787878">STRENGTH : 32</h4>
     <h4 style="color:#787878">CONTACT:1478523697</h4>
   </div>
   <div class="column" style="background-color:white;">
      <h2 align=right> <a href="http://www.hyperlinkcode.com/button-links.phphttp://www.hyperlinkcode.com/button-links.php" class="previous round" >&#8249;</a>
                  <a href="http://www.hyperlinkcode.com/button-links.php" class="next round">&#8250;</a></h2>
                  <br>
      <h4 align="right" style="color:#787878">Need Rs.36000 more of Rs.54000 </h4>
     <div class="absolute">
      <div class="outter"><div class="inner"  ></div></div>
     </div>
    </div>
  </div>
<img src="download1.jpg" alt="download1.jpg"  align="center" style="width:75%">
<br>

<div align="center">
 <button class="botton"onclick="window.location.href='http://www.hyperlinkcode.com/button-links.php'"> DONATE </button>
 <button class="botton"onclick="window.location.href='http://www.hyperlinkcode.com/button-links.php'"> VOLUNTEER </button>
</div>
<p align="justify"style="color: #787878">Content inside this container is centered horizontally.Learn how to create an responsive image with CSS.Responsive images will automatically adjust to fit the size of the screen.Resize the browser window to see the responsive effect:</p>
<br>
<br>
<br>
</div>
</body>
</html>
 <?php
 $total=54000;
 $need=36000;
 $aa=$total-$need;
 $person=round(($aa/$total)*100,1);

 ?>
 <style type="text/css">
 .outter {
  
  background-color: lightgrey;
  height:15px;
  width: 200px;
  
 }
 .inner {

  height:15px;
  width: <?php echo $person ?>%;
 
 background-color: orange;
}

 </style>